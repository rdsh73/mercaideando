## Juego de Memoria

El juego consiste en encontrar las parejas de cada carta, al comienzo se muestra un tablero que en función del nivel de dificultad (fácil, medio o dificil) tendrá más o menos cartas.

Como hemos indicado el juego posee 3 niveles de dificultad y cada uno de ellos posee una mano de cartas diferente, dichas cartas se reparten de manera aleatoria al inicio de cada partida.

Cada partida acumulara puntos en función del número de fallos y controlara la duración de la partida con un temporizador. Al finalizar la partida, la puntos se registraran en la tabla de puntuaciones para poder compararlos con las mejores puntuaciones de de otros jugadores.

Podrá acceder a la ultima versión del juego desde el siguiente enlace: https://elvirarguez.github.io/parejas-memoria/
